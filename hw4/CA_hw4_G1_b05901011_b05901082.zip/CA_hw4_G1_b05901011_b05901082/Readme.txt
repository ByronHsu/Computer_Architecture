cycle time: 14.0
FPU Single: Y
FPU Double: Y